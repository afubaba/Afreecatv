// console.log("bj.afreecatv.js");
// const bgURL=chrome.runtime.getURL("img/11.png");
// getURL();


// https://afubaba.github.io/Afreecatv/

// dynamicLoading.js("https://afubaba.github.io/Afreecatv/js/common.js");


dynamicLoading.css("https://afubaba.github.io/Afreecatv/libs/bootstrap/2.3.2/css/bootstrap.min.css",function(){
	// console.log("bootstrap.min.css");
});
function getURL() {
	try {
		const bgURL = document.getElementsByClassName("thum")[0].style.backgroundImage;
		//console.log(bgURL);
		//修改图标
		$('link[rel="shortcut icon"]').attr('href', "//profile.img.afreecatv.com/LOGO/tn/tntntn13/tntntn13.jpg");

		$('*').css('background', 'none');
		// $('*').css('backgroundImage', 'none');

		//设置背景图
		//bgBackgroundFunction(bgURL1);
	} catch (e) {
		setTimeout(function() {
			getURL();
		}, 1000);
	}
}

function setIcon(newSrc) {
	// 处理事件的逻辑
	//console.log('目标 <img> 的 src 属性发生变化:', newSrc);
	var imgSrc = new URL(newSrc, window.location.href).href;
	//imgSrc = "https:" + imgSrc;

	//修改图标
	$('link[rel="shortcut icon"]').attr('href', imgSrc);

}

var attemptCount = 0; // 尝试计数器
function observeTarget() {
	if (attemptCount >= 50) {
		//console.log('目标元素不存在，无法监听');
		return;
	}
	// 判断目标元素是否存在
	if ($('.bj_box img').length) {
		// 使用 jQuery 查找目标 <img> 元素
		var targetImg = $('.bj_box img');
		// 获取初始的 src 属性值
		var initialSrc = targetImg.attr('src');
		// 初次设置图片
		setIcon(initialSrc);
		// 创建一个 MutationObserver 实例
		var observer = new MutationObserver(function(mutationsList) {
			mutationsList.forEach(function(mutation) {
				// 检查是否是目标 <img> 元素的 src 属性发生了变化
				if (mutation.type === 'attributes' && mutation.attributeName === 'src') {
					// 获取新的 src 属性值
					var newSrc = targetImg.attr('src');

					// 初次设置图片
					setIcon(newSrc);
				}
			});
		});

		// 配置观察选项
		var config = {
			attributes: true, // 监听属性的变化
		};

		// 开始观察目标 <img> 元素的 src 属性变化
		observer.observe(targetImg[0], config);


	} else {
		// 目标元素不存在，计数器加1并继续尝试
		attemptCount++;
		setTimeout(observeTarget, 1000); // 间隔1秒后继续尝试
	}
}
//observeTarget(); // 开始尝试监听目标元素
getURL();
var bdBack = document.body;

function bgBackgroundFunction(bgURL) {
	bdBack.style.backgroundImage = bgURL; //设置背景图的的地址
	bdBack.style.backgroundRepeat = "no-repeat"; //设置背景不平铺
	bdBack.style.backgroundPosition = "center"; //设置背景图的位置
	bdBack.style.backgroundSize = "cover"; //设置背景图像的尺寸 
}
// $(bdBack).css('background', 'none');
// bdBack.background=bgURL;
// document.body.style.backgroundSize="100%";
// document.body.style.backgroundWidth="100%";
// document.body.style.background.height="100%";
//css
// .bj {
//       background: url(star.jpg) no-repeat center;
//       background-size: cover;
// }
//.css('background-size','100%').css('height','100%').css('width','100%');




//https://bj.afreecatv.com/kus03125/posts/instagram
//注入事件

//追加打开全部
// document.getElementsByClassName("btn-more")[1].append("<button>nihao</button>");

//模拟单次点击
// document.getElementsByClassName("btn-more")[1].children[0].click()
window.onload = function() {
	// console.log($(".btn-more"));
	// console.log($(".btn-more")[0]);
	// $(".btn-instagram").
	// setInterval(function(){

	// 	var btnLengt=$(".btn-more").length;
	// 	if(btnLengt=="2"){
	// 		$(".btn-more:eq(1)").append("<button>nihao</button>");
	// 	}
	// 	console.log($(".btn-more").length);
	// },1000);


}
//2.$(function($){});

// (function($){})(jQuery);
//展开全部
// $(function($) {
//.trigger("click", ["foo", "bar"]);自动点击复制.btn-instagram,
//1. 交集选择： $(".a.b") --选择同时包含a和b的元素。2. 并集选择：$(".a, .b") --选择包含a或者包含b的元素。

//添加展开全部按钮
let j = 0;
let addClickEventsInterval = setInterval(function() {

	// console.log(j);
	// console.log($(".btn-instagram").length);
	// console.log(document.readyState);
	if (j >= 40) {
		clearInterval(addClickEventsInterval);
	}
	if ($(".sns-instargram").length == "1" || $(".btn-instagram").length == "1") {
		$(".sns-instargram,.btn-instagram").click(function(event, a, b) {
			addOpenAllFunction();
		});
		clearInterval(addClickEventsInterval);
	}
	j++;

}, 250);
//添加
addOpenAllFunction();
async function addOpenAllFunction() {
	let i = 0;
	let addButtonInterval = setInterval(function() {
		let btnMore = $(".snsBoard-insta").children(".btn-more");
		// console.log(btnMore.length);
		i++;
		// console.log(i);
		//10次添加失败停止
		if (i >= 10) {
			clearInterval(addButtonInterval);
		}
		if (btnMore.length == 1) {
			//提前删除一次
			$("#openAll").remove();
			$(".snsBoard-insta").append(
				"<button id='openAll' class='btn btn-danger' style='width:100%;height:" +
				btnMore.height() + "px'>" + getI18n("bj_afreecatv_openAll") + "</button>");
			$("#openAll").click(function() {

				const isOpenAll = confirm(getI18n("bj_afreecatv_openAll_tip") + "?");
				if (isOpenAll) {
					let openAllInterval = setInterval(function() {
						// if ('undefined' != typeof handTimeout) {
						// 	clearInterval(handTimeout);
						// }
						// console.log($(".snsBoard-insta").children(".btn-more").length);
						if ($(".snsBoard-insta").children(
								".btn-more")
							.length ==
							"0") {
							// console.log("已经展开了全部");
							$("#openAll").remove();
							clearInterval(openAllInterval);
						}

						btnMore.children().click();
						//控制顶级滚动条的位置
						window.scrollTo(0, document.body
							.scrollHeight);
					}, 1000);
				}
			});
			clearInterval(addButtonInterval);
		}
		//console.log($(".snsBoard-insta").children(".btn-more").append(" < button > nihao < /button>"));
		// console.log(document.readyState);
	}, 1000);
}
// });


//本地化
function getI18n(name) {
	const rnName = chrome.i18n.getMessage(name);
	return rnName;
}

function setLanguage(idName) {
	var rnName = getI18n("bj_afreecatv_" + idName);
	console.log(idName + ":" + rnName);
	if (rnName != "") {
		$("#" + idName).html(rnName);
	}

}
//批量调用
/* const idNameAarray = [""];
idNameAarray.forEach(function(idName) {
	setLanguage(idName);
}) */
;
