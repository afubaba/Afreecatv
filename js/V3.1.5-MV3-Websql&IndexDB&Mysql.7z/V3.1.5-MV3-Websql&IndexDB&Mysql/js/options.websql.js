var db;
var msg;
var opWebsql = {
	getDB: function() {
		db = openDatabase('optionsDB', '1.0', 'TestDB', 2 * 1024 * 1024, function(result) {
			db = result;
		});
		if (!db) {
			console.log("数据库创建失败！");
			return;
		} else {
			console.log("数据库创建成功！");
		}
	},
	seachData: function(tbName) {
		this.getDB();
		db.transaction(function(tx) {
			tx.executeSql('SELECT * FROM ' + tbName, [], function(tx, results) {

				// console.log(results.rowsAffected);
				
				var data=results.rows[0];
				
				console.log(data);
				getDomById("background_color").value = data.fontColor;
				getDomById("background").value = data.backColor;
			}, null);

		});

	},
	insertData: function(extensionId) {
		this.getDB();
		db.transaction(function(tx) {
			console.log("insertData");
			console.log(extensionId);
			var tbName = "OPTIONS";
			//删除表格数据
			// tx.executeSql('DELETE FROM '+tbName);
			//删除表格
			var sql ='DROP TABLE ' + tbName;
			// tx.executeSql(sql);
			tx.executeSql('CREATE TABLE IF NOT EXISTS ' + tbName + ' (id unique, fontColor,backColor)');
			tx.executeSql('INSERT INTO ' + tbName +
				'(id, fontColor,backColor) VALUES ("' + extensionId + '", "?","?")');

			// msg = '<p>数据表已创建，且插入了两条数据。</p>';
			console.log(msg);
		});
	},
	updateData: function(option, tbName) {
		console.log(option);
		this.getDB();
		console.log(db);
		// db.transaction(function(tx) {
		// 	// var sql="UPDATE " + tbName + " SET fontColor='nice' ,  backColor='good'";
		// 	var sql="UPDATE " + tbName + " SET fontColor='"+option.fontColor+"' ,  backColor='"+option.backColor+"'";
		// 	console.log(sql);
		// 	tx.executeSql(sql);
		// });
		db.transaction(function(tx) {
			// var sql="UPDATE " + tbName + " SET fontColor='nice' ,  backColor='good'";
			var sql = "UPDATE " + tbName + " SET fontColor='" + option.fontColor + "' ,  backColor='" +
				option.backColor + "'";

			tx.executeSql(sql, [], function(tx, results) {

				console.log(results);

			});
		});
	}
}
