
// alert("popub.js");
// chrome.runtime.sendMessage('Hello', function(response){
//       alert(response);
// });

document.addEventListener('DOMContentLoaded', function() {
  // chrome.tabs.sendRequest(tab.id, { action:  "Test"  },  function  (response) {
  //   alert(response.kw);
  // });

  var checkPageButton = document.getElementById('clickIt');
  checkPageButton.addEventListener('click', function() {


    chrome.tabs.getSelected(null, function(tab) {
      alert("Hello..! It's my first chrome extension.");
      chrome.tabs.sendRequest(tab.id, { action:  "Test"  },  function  (response) {
        response.kw.background="url('https://profile.img.afreecatv.com/LOGO/10/1057123999/1057123999.jpg')"
        alert(response.kw);
     });
    });
  }, false);

  //  var checkPageButton = document.getElementById('clickIt');
  // checkPageButton.addEventListener('click', function() {

  //   chrome.tabs.getSelected(null, function(tab) {
  //     alert("Hello..! It's my first chrome extension.");
  //     chrome.tabs.sendRequest(tab.id, { action:  "GetBaiduKeyWord"  },  function  (response) {

  //      alert(response.kw);
  //    });
  //   });
  // }, false);
}, false);
