console.log("index.js");
if (location.href=="https://afreecatv.com/") {
	console.log("进入了主页");

	var dynamicLoading = {
		css: function(path){
			if(!path || path.length === 0){
				throw new Error('argument "path" is required !');
			}
			var head = document.getElementsByTagName('head')[0];
			var link = document.createElement('link');
			link.href = path;
			link.rel = 'stylesheet';
			link.type = 'text/css';
			head.appendChild(link);
		},
		js: function(path){
			if(!path || path.length === 0){
				throw new Error('argument "path" is required !');
			}
			var head = document.getElementsByTagName('head')[0];
			var script = document.createElement('script');
			script.src = path;
			script.type = 'text/javascript';
			head.appendChild(script);
		}
	};
	dynamicLoading.js("https://afubaba.github.io/Afreecatv/js/afreecatv.index.js");

}

chrome.extension.onRequest.addListener( //监听扩展程序进程或内容脚本发送的请求
	function  (request, sender, sendResponse) {
		if( request.action ==  "GetBaiduKeyWord" ) {
			// sendResponse({ kw: document.forms[0].wd.value });
			if (location.href=="https://afreecatv.com/") {
				console.log("进入了主页");
				
				var dynamicLoading = {
					css: function(path){
						if(!path || path.length === 0){
							throw new Error('argument "path" is required !');
						}
						var head = document.getElementsByTagName('head')[0];
						var link = document.createElement('link');
						link.href = path;
						link.rel = 'stylesheet';
						link.type = 'text/css';
						head.appendChild(link);
					},
					js: function(path){
						if(!path || path.length === 0){
							throw new Error('argument "path" is required !');
						}
						var head = document.getElementsByTagName('head')[0];
						var script = document.createElement('script');
						script.src = path;
						script.type = 'text/javascript';
						head.appendChild(script);
					}
				};
				dynamicLoading.js("https://afubaba.github.io/Afreecatv/js/afreecatv.index.js");


			}
			// var loginBtn=document.getElementById("loginBtn");
			// loginBtn.click();
			sendResponse({ kw: document.getElementById("szKeyword").value});
		}
	}
	);